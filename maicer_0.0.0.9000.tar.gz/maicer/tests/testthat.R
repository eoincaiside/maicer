library(testthat)
library(maicer)

test_check("maicer")
